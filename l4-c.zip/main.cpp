#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    //int a, b, c;
    //cout<<"a=";
    //cin>>a;
    //cout<<"b=";
    //cin>>b;
    //c=pow(a,2)+2*a*b+pow(b,2);
    //cout<<"c="<<c;
    //c=sqrt(pow(a,2)+pow(b,2));
    
    
    //int x, y, z;
    //x=5;
    //y=7;
    //z=(x>y)? x:y;
    //cout<<z;
    //if(x>y)
    //    z=x;
    //else
    //    z=y;
    
    
    //int a, b, c, max;
    
    
    //cout<<"a=";
    //cin>>a;
    //cout<<"b=";
    //cin>>b;
    //cout<<"c=";
    //cin>>c;
    
    //if((a>b) && (a>c))
    //    max = 1;
    //else
    //    if((b>a) && (b>c)
    //        max = 2;
    //    else
     //       if((c>a) && (c>b))
    //            max = 3;
                
    
    
    //switch (max)
    {
   //     case 1:
   //         cout<<"primul";
   ////         break;
   //     case 2:
   //         cout<<"al doilea";
   //         break;
   //     case 3:
   //         cout<<"al treilea";
   //         break;
    }
    /*
    char ch = 'f';
    switch(ch)
    {
        case 'a':
            cout<<"a";
            break;
        case 'z':
            cout<<"z";
            break;
        case 'f':
            cout<<"f";
            break;
        default:
            cout<<"33";
    }
    */
    
    /*
    int a = 7;
    switch(a)
    {
        case 1:
            cout<<"a=1";
            break;
        case 7:
            cout<<"a=7";
            break;
        default:
            cout<<"alta valoare";
    }
    */
    /*
    int a, b, op;
    cin>>a;
    cin>>b;
    switch(op)
    {
        case '/':
            cout<<"a/b";
            break;
        case '*':
            cout<<"a*b";
            break;
        case '+':
            cout<<"a+b";
            break;
        case '-':
            cout<<"a-b";
            break;
        default:
            cout<<"nu merge";
    }
    */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    return 0;
}


