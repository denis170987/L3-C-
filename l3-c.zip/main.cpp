#include <iostream>
#include <cmath>
using namespace std;

int
main ()
{
  int v, g, h;

  v = 1;
  g = 3;
  h = 5;
  //cout<<v<<endl<<g<<endl<<h<<endl;

  //Operatori de atribuire comlecsi
  // +=, -=, *=, /=, %=

  //v*=3;//v=v*3;
  // cout<<v<<endl;
  // g+=2;
  // cout<<g<<endl;
  // h-=6;
  // cout<<h<<endl;

  //Operatori de incrementare/decrementatre ++/--
  //v++;
  //g++;
  //cout<<v<<endl<<g<<endl;

  //v=h++; //v ia valoarea lui h, apoi h creste cu 1;
  //v=++h; //mai intai valoarea lui h creste cu 1, apoi v ia valoarea lui h;
  //cout<<v<<endl<<h<<endl;

  //v=h--; // <=> v=h; h=h-1;
  //v=--h; // <=> h=h-1; v=h;
  //cout<<v<<endl<<h<<endl;

  //Operatorul conditional ? => expresie / val1 : val2
  //cout<<(v%2 == 0 ? "par" : "impar");

  //interschimbarea a doua variabile
  //1: folosind o variabila
//   int aux;
  //aux = g;
  //g = v;
  //v = aux;
  //cout << g <<" "<<v<<endl;

  //2: prin adunari si scaderi succesive
  //cout << h <<" "<<v<<endl;
  //v = v-h;// v1 = suma
  //h = v-h;// v2 = suma - v2
  //v = v-h;// v1 = suma - v2
  //cout << h <<" "<<v<<endl;

  //if(expresie)

  //else

  // */

  //if(h%2){
  //      cout<<"impar";
  // }
  //else{
  //    cout<<"par";
  //}    
  //v=0;
  //if(v)
  //   cout<<"nenul";
  //else
  //  cout<<"nul";

  if (v < h)

    cout << "v < h " << endl;
  else
    cout << "v > h " << endl;

  if (v < g)
    cout << "v < g " << endl;
  else
    cout << "v > g " << endl;

  if (v = v)

    cout << "v = v";
  else
    cout<< "v < v/v > v";


  return 0;
}

