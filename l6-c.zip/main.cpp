#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    // int n ,i1 ,i2 ,i3;
    // cout<<"n=";
    // i3=0;
    // cin>>n;
    // for(i1=1; i1<=n; i1++){
    //     for(i2=1; i2<=i1; i2++){
    //         //cout<<"*";
    //         //cout<<i2<<" ";
    //         //cout<<i3++<<" ";
        
        
        //cout<<endl;
    //}
    
    //int a, b, c, d, e;
    
    // if(a==0)
    // {
    //     if(b==0)
    //     {
    //         if(c==0)
    //         {
    //             if(d==0)
    //             {
    //                 if(e==0)
    //                 {
    //                     cout<<"FINAL!";
    //                 }
                   // else
                    {
                       //  cout<<"S-a blocat la D";
                    }
    //                
    //             }
                
    //             cout<<"S-a blocat la C";
    //         }
            
    //         cout<<"S-a blocat la B";
    //     }
        
    //     cout<<"S-a blocat la A";
    // }
//     void functie
    
//   if(a!=0)
//   {
//      cout<<"S-a blocat la A";
//      return;
//   }
//     if(b!=0)
//   {
//      cout<<"S-a blocat la B";
//      return;
//   }
//     if(c!=0)
//   {
//      cout<<"S-a blocat la C";
//      return;
//   }
//     if(d!=0)
//   {
//      cout<<"S-a blocat la D";
//      return;
//   }
//     if(e!=0)
//   {
//      cout<<"S-a blocat la E";
//      return;
//   }
    
//     cout<<"FINAL";
    
    
    // int a, b, i, j;
    
    // cin>>a>>b;
    //  if(b<a)
    //     {
    //         int aux;
    //         aux=a;
    //         a=b;
    //         b=aux;
    //     }
    // for(i=b;i>=a;i--)
    //     if(i%2==1)
    //     cout<<i<<" ";
        
    
    
//   int n, cifra, suma;
//   cin>>n;

// while(n!=0)
// {
//     cifra=n%10;
//     suma=suma+cifra;
//     n/=10;
    
// }
//   cout<<"suma= "<<suma;
    
    
    
//   int cifra, intrus, n, nr_apariti=0;
//   cout<<"n= ";
//   cin>>n;
//   cout<<"intrus= ";
//   cin>>intrus;
//   while(n!=0)
//   {
//       cifra=n%10;
//       if(cifra==intrus)
//       {
//           nr_apariti++;
//       }
       
//       n/=10;
//   }
//     cout<<"intrusul apare de "<<nr_apariti<<" ori";
    
    
    
    int n,max=-1;
    cin>>n;
    while(n!=0)
    {
        int c=n%10;
        if(c>max)max=c;
             n=n/10;
    }
        cout<<max;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    return 0;
}
