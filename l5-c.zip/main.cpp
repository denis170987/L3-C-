#include <iostream>
#include <cmath>
using namespace std;

int main()
{
//     int n, s=0;
//     cout<<"introduceti nr n:";
//     cin>>n;
//     //while (n != 0)
//     for (int i=0;i<=nr_cifre )
//      {
//          s = s + n % 10; 
// 	    	n = n / 10; 
//      }
//       cout << "Suma cifrelor lui n este: " << s;


      int n, nr_cifre, cifra;
      cout<<"introduceti nr n:";
      cin>>nr_cifre;
      
      int s=0;
      for(int i=0; i<nr_cifre; i++)
      {
        cifra=n%10;
        s+=cifra;
         n=n/10;
      }
      
      cout<<" suma cifrelor lui n este "<<s<<endl;
      
      
      
    return 0;
}

